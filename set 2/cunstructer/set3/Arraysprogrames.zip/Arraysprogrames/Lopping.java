//Sum of digits number and sum of sum of digitsnumber ;
import java.util.*;
class Lopping
{
	
public static void main(String [] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the digit value ");
	int n=sc.nextInt();
	while(n>0)
		{
		int sum=0;
				while(n>0)
				{
					int digit=n%10;
					sum=sum+digit;
					n=n/10;
				}
				System.out.println(sum);
				if(sum/10!=0)
				n=sum;
		
			}
			Calendar ce=Calendar.getInstance();
			System.out.println(ce.get(Calendar.DATE));

	}

}