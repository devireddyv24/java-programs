import java.util.*;
class Dublicat
{
	public void main()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter the value of length");
		int a=s.nextInt();
		int b[]=new int[a];
		int c[]=new int[a];
	
		for(int i=0;i<a;i++)
		{
			b[i]=s.nextInt();
		}
		for(int i=0;i<a;i++)
		{
			int count=1;
			for(int j=i+1;j<a;j++)
			{
				if(b[i]==b[j])
				{
					count++;
					c[j]=1;
				}
			}
			if(count>1&&c[i]!=1)
			{
				System.out.println( "dublicate nois: "+b[i]);
			}
		}
}
public static void main(String [] args)
	{
	Dublicat d=new Dublicat();
	d.main();
	}
}
