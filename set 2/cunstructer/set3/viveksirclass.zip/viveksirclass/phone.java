class phone
{
	String mm;
	String sim;
	Spekar ms;
phone(String mm,String sim,Spekar ms){
	this.mm=mm;
	this.sim=sim;
	this.ms=ms;
	System.out.println(this.ms);
}
public void musice()
	{
	ms.sound();
		System.out.println("very good");
	}
}