class Stop
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
			System.exit(0);
		try{
			int a[]=new int[5];
			System.out.println("enter the msgs");
			System.exit(0);
			System.out.println("comp;eted");
			System.out.println(a[20]);

		}
		catch(Exception e)
		{
			System.out.println("heelo how r u");
		}


	}
}
