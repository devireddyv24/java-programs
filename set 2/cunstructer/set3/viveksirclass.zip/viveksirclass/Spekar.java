class Spekar
{
	String wr;
	String pd;
	String bt;
	Spekar(String wr,String pd)
	{
		this.wr=wr;
		this.pd=pd;
	}
	public void sound()
	{
		System.out.println("very loud");
	}
}